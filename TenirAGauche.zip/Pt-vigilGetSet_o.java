/* variable c_vig - CopyRight MT-TAG  - */ private int c_vig; // Getter Setter de c_vig - CopyRight MT-TAG - public int getC_vig   { return c_vig; }   public void setC_vig (int c_vig){ this.c_vig =  c_vig; } 
 
/* variable lib_vig - CopyRight MT-TAG  - */ private Sring lib_vig; // Getter Setter de lib_vig - CopyRight MT-TAG - public Sring getLib_vig   { return lib_vig; }   public void setLib_vig (Sring lib_vig){ this.lib_vig =  lib_vig; } 
 
/* variable c_tri_vig - CopyRight MT-TAG  - */ private int c_tri_vig; // Getter Setter de c_tri_vig - CopyRight MT-TAG - public int getC_tri_vig   { return c_tri_vig; }   public void setC_tri_vig (int c_tri_vig){ this.c_tri_vig =  c_tri_vig; } 
 

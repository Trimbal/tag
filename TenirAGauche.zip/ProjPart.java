package bdd;

import habillage.dao.UserProfilDAO;

import java.sql.Connection;
import java.util.Vector;


import dao.DAOException;

import bdd.dao.ProjPartDAO;

/**
 * 

 *
 */

public class ProjPart implements Cloneable {
	
	private String libproj;
	private String libpart;
	private String idpart;
	private String idcoord;
	private float dc;
	public float getDc() {
		return dc;
	}
	public void setDc(float dc) {
		this.dc = dc;
	}
	public String getIdcoord() {
		return idcoord;
	}
	public void setIdcoord(String idcoord) {
		this.idcoord = idcoord;
	}

	private String otp; 
	private int numsite;
	private String libsite; 
	private String libreg; 
	
	public int getNumsite() {
		return numsite;
	}
	public void setNumsite(int numsite) {
		this.numsite = numsite;
	}
	public String getLibsite() {
		return libsite;
	}
	public void setLibsite(String libsite) {
		this.libsite = libsite;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getIdpart() {
		return idpart;
	}
	public void setIdpart(String idpart) {
		this.idpart = idpart;
	}

	protected static Vector listProjPart;
	
	public String getLibproj() {
		return libproj;
	}
	public void setLibproj(String libproj) {
		this.libproj = libproj;
	}
	public String getLibpart() {
		return libpart;
	}
	public void setLibpart(String libpart) {
		this.libpart = libpart;
	}
	
	public static void creerListProjPart(Connection conn){
    	try{
        	if(listProjPart==null){
	    		ProjPartDAO upDAO = new ProjPartDAO();
	    		listProjPart = upDAO.findAll(conn);
	    		upDAO = null;
        	}
        }
        catch(Exception e){
        	commun.Log.error("erreur dans creerListProjPart : "+e);
        }
    }
	
	/*
	 * Auteur : Andr� Guidi, le 10/04/2015 
	 * Partenaire coordinateur 
	 */
	
	public ProjPart litCoord(Connection conn,String otp)
	{            ProjPart pp=new ProjPart();
  
				try {
					Object oo=new Object();
	
			ProjPartDAO ppDAO= new ProjPartDAO();
	    	oo=ppDAO.loadCoord(conn, otp);
            pp=(ProjPart)oo;
            
			
		}
		
		catch (Exception e)
		{
		   commun.Log.error("Erreur dans litCoord "+e);	
		}
		return pp;
	}
	
	
	/*
	 *  Auteur : Andr� Guidi, le 14/04/2015 
	 *  Lecture de tous les partenaires dans la table Siret-anr-part 
	 */
	
	 public Vector<ProjPart> litPart(Connection conn,String otp)
	 {
		 Vector <ProjPart> v=new  Vector() ;
		 try 
		 {
			 ProjPartDAO ppdao=new ProjPartDAO();
			 v=ppdao.loadPart(conn, otp);
		 }
		 catch (Exception e)
		 {
			 commun.Log.error("Erreur dans litPart");
		 }
		 return v; 
	 }
	 
	 
	  /**
	   *   Andr� Guidi : le 01/02/2016 
	   * 
	   * 
	   * Efface le lien dans ProjPart
	   * 
	   * 
	   */
		public void supprimerLien(Connection conn) throws DAOException {
	     	try{
	         	ProjPartDAO ppDAO = new ProjPartDAO();
	             ppDAO.delete(conn, this);
	             ppDAO = null;
	         }
	         catch(DAOException daoe){
	         	throw daoe;
	         }
		}
		
		
		/**
		 * 
		 *  ajouter un partenaire 
		 * 
		 * 
		 */
		
		public void add(Connection conn) throws DAOException {
			try {
				ProjPartDAO ppDAO=new ProjPartDAO();
				ppDAO.insert(conn, this);
				ppDAO=null; 
				
			}
			
			catch(DAOException daoe){
				 throw daoe;
			}
			
			
		}
		
		/**
		 *  Mettre � jour un partenaire 
		 * 
		 * 
		 */
		
		public void upd(Connection conn) throws DAOException {
			try {
				ProjPartDAO ppDAO=new ProjPartDAO();
				ppDAO.update(conn, this);
				ppDAO=null; 
				
			}
			
			catch(DAOException daoe){
				 throw daoe;
			}
			
			
		}
		
		

	    public Object clone(){
	    	try {
				return super.clone();
			} 
	    	catch (CloneNotSupportedException e) {
				e.printStackTrace();
				return null;
			}
	    }
		public String getLibreg() {
			return libreg;
		}
		public void setLibreg(String libreg) {
			this.libreg = libreg;
		}
	    

}

public class Exemple {
  public static void main(String[] args)
  {
     System.out.println("coucou");
      }
}
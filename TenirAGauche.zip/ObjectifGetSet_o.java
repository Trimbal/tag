/* variable c_obj - CopyRight MT-TAG  - */ private int c_obj; // Getter Setter de c_obj - CopyRight MT-TAG - public int getC_obj   { return c_obj; }   public void setC_obj (int c_obj){ this.c_obj =  c_obj; } 
 
/* variable lib_obj - CopyRight MT-TAG  - */ private Sring lib_obj; // Getter Setter de lib_obj - CopyRight MT-TAG - public Sring getLib_obj   { return lib_obj; }   public void setLib_obj (Sring lib_obj){ this.lib_obj =  lib_obj; } 
 
/* variable c_tri_obj - CopyRight MT-TAG  - */ private int c_tri_obj; // Getter Setter de c_tri_obj - CopyRight MT-TAG - public int getC_tri_obj   { return c_tri_obj; }   public void setC_tri_obj (int c_tri_obj){ this.c_tri_obj =  c_tri_obj; } 
 

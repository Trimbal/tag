/* variable c_dom - CopyRight MT-TAG  - */ private int c_dom; // Getter Setter de c_dom - CopyRight MT-TAG - public int getC_dom   { return c_dom; }   public void setC_dom (int c_dom){ this.c_dom =  c_dom; } 
 
/* variable lib_dom - CopyRight MT-TAG  - */ private Sring lib_dom; // Getter Setter de lib_dom - CopyRight MT-TAG - public Sring getLib_dom   { return lib_dom; }   public void setLib_dom (Sring lib_dom){ this.lib_dom =  lib_dom; } 
 
/* variable c_tri_dom - CopyRight MT-TAG  - */ private int c_tri_dom; // Getter Setter de c_tri_dom - CopyRight MT-TAG - public int getC_tri_dom   { return c_tri_dom; }   public void setC_tri_dom (int c_tri_dom){ this.c_tri_dom =  c_tri_dom; } 
 

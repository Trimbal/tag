

// Getter Setter de {%var_min%} - CopyRight MT-TAG - 

public {%typ%} get{%var_maj%}
   { return {%var_min%}; }
   
public void set{%var_maj%} ({%typ%} {%var_min%})
{ this.{%var_min%} =  {%var_min%}; }

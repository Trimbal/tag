create or replace database ASPH
 default character set utf8
 collate utf8_general_ci;
create or replace table `ASPH`.Action(
        otp Varchar(30),
        acr_act Varchar(20),
        lib_act Varchar(500),
        datdeb_act date,
        datfin_act date,
        dc decimal(12,2),
        dnc decimal(12,2),
        idnc decimal(12,2),
        ction decimal(12,2),
        otp_ori Varchar(30));
create or replace table `ASPH`.Typ_act(
        c_typ_act int(5),
        lib_typ_act Varchar(50),
        c_tri_act int(10));
create or replace table `ASPH`.Domaine(
        c_dom int(5),
        lib_dom Varchar(50),
        c_tri_dom int(10));
create or replace table `ASPH`.Porteur(
        cod_porteur Varchar(14),
        lib_port Varchar(500),
        datdeb date,
        datfin date,
        dc decimal(12,2),
        dnc decimal(12,2),
        idnc decimal(12,2),
        ction decimal(12,2),
        verst decimal(12,2));
create or replace table `ASPH`.Partenaire(
        cod_partenaire Varchar(14),
        lib_part Varchar(500),
        datdeb date,
        datfin date,
        dc decimal(12,2),
        dnc decimal(12,2),
        idnc decimal(12,2),
        ction decimal(12,2),
        verst decimal(12,2));
create or replace table `ASPH`.Objectif(
        c_obj decimal(5),
        lib_obj Varchar(50),
        c_tri_obj int(10));
create or replace table `ASPH`.Pt_vigil(
        c_vig decimal(5),
        lib_vig Varchar(50),
        c_tri_vig int(10));
create or replace table `ASPH`.Indic(
        c_ind decimal(5),
        lib_ind Varchar(50),
        c_tri_ind int(10));

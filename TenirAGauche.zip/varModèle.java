/* variable {%var_min%} - CopyRight MT-TAG  - */ 

private {%typ%} {%var_min%}; 
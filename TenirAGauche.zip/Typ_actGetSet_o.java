/* variable c_typ_act - CopyRight MT-TAG  - */ private int c_typ_act; // Getter Setter de c_typ_act - CopyRight MT-TAG - public int getC_typ_act   { return c_typ_act; }   public void setC_typ_act (int c_typ_act){ this.c_typ_act =  c_typ_act; } 
 
/* variable lib_typ_act - CopyRight MT-TAG  - */ private Sring lib_typ_act; // Getter Setter de lib_typ_act - CopyRight MT-TAG - public Sring getLib_typ_act   { return lib_typ_act; }   public void setLib_typ_act (Sring lib_typ_act){ this.lib_typ_act =  lib_typ_act; } 
 
/* variable c_tri_typ_act - CopyRight MT-TAG  - */ private int c_tri_typ_act; // Getter Setter de c_tri_typ_act - CopyRight MT-TAG - public int getC_tri_typ_act   { return c_tri_typ_act; }   public void setC_tri_typ_act (int c_tri_typ_act){ this.c_tri_typ_act =  c_tri_typ_act; } 
 

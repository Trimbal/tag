package bdd;

import java.sql.Connection;

import bdd.dao.ProjPartDAO;
import bdd.dao.SiteDAO;

/**

 *
 */


public class Site {
	
	
	private int numSite;
	private String sigle;
	private String lib;
	private String cod; 
	public int getNumSite() {
		return numSite;
	}
	public void setNumSite(int numSite) {
		this.numSite = numSite;
	}
	public String getSigle() {
		return sigle;
	}
	public void setSigle(String sigle) {
		this.sigle = sigle;
	}
	public String getLib() {
		return lib;
	}
	public void setLib(String lib) {
		this.lib = lib;
	} 
	
/*
 * 
 */
	
	
	
	public Site litSite(Connection conn,String otp)
	{            Site s=new Site();
  
				try {
					Object oo=new Object();
	
			SiteDAO sDAO= new SiteDAO();
	    	oo=sDAO.loadSite(conn, otp);
            s=(Site)oo;
            
			
		}
		
		catch (Exception e)
		{
		   commun.Log.error("Erreur dans litSite "+e);	
		}
		return s;
	}
	public String getCod() {
		return cod;
	}
	public void setCod(String cod) {
		this.cod = cod;
	}
	
	

}

package bdd.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import habillage.IdentRepStruct;
import bdd.ActionPia;
import bdd.Etab;

import bdd.Site;
import bdd.TypePia;
import habillage.Log;
import bdd.Reg;
import habillage.dao.CodeSQL;

import dao.DAOException;

public class ActionPiaDAO implements dao.IDAO {
	
	private static String reqSqlCoord;

	public static String getReqSqlCoord() {
		return reqSqlCoord;
	}

	public void setReqSqlCoord(String req) {
		reqSqlCoord = req;
	}
    
	
	private static String reqSqlPart;

	public static String getReqSqlPart() {
		return reqSqlPart;
	}

	public void setReqSqlPart(String req) {
		reqSqlPart = req;
	}
	
	private static String reqSqlCoordMemb;

	public static String getReqSqlCoordMemb() {
		return reqSqlCoordMemb;
	}

	public void setReqSqlCoordMemb(String req) {
		reqSqlCoordMemb = req;
	}
    
	
	private static String reqSqlPartMemb;

	public static String getReqSqlPartMemb() {
		return reqSqlPartMemb;
	}

	public void setReqSqlPartMemb(String req) {
		reqSqlPartMemb = req;
	}
	
	// 
	
	private static Boolean memb;
	
	public static Boolean getMemb(){
		return memb;
	}
	
	public void setMemb(Boolean b)
	{
		memb=b;
	}


	@Override
	public void delete(Connection arg0, Object arg1) throws DAOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Vector findAll(Connection arg0) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	public void insert(Connection conn, Object obj,String typact,String ancval) {
		ActionPia act=(ActionPia) obj;
		try
		{
			PreparedStatement stmt=null;
			stmt=conn.prepareStatement(sqlInsAction);
			stmt.setString(2, act.getLibAction());
			stmt.setString(1, act.getOtp());
			stmt.setString(3, act.getAcronyme());
			Log.info(this,"Site "+act.getSit().getNumSite()); 
			stmt.setInt(4, act.getSit().getNumSite());
			stmt.setInt(5, act.getTpia().getNum());
			stmt.setString(6, act.getpCoord().getIdcoord());
			stmt.setString(7,act.getOtp());
		    habillage.Log.info(this, "sql ins "+stmt);
			stmt.executeUpdate();
        	stmt.close();
        	upTypAct(conn,obj);
        	gestCoord(conn,obj,typact,ancval);
        	Log.info(this, "Retour Ok");
        	//conn.close();
		}
		catch (SQLException sqle)
		{
			habillage.Log.error(this,"Erreur ins Action DAO "+sqle);
		}
		
	}

	@Override
	public Object load(Connection arg0, Object arg1) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	public Object loadVerst(Connection conn, String otp) throws DAOException {
		// 
		ActionPia a = new ActionPia();
		try
		{
			PreparedStatement stmt = conn.prepareStatement(sqlLitVerst);
			stmt.setString(1, otp);
			//commun.Log.info(this,"Inst sql verst "+stmt);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                	a.setVerst(rs.getFloat("Verst"));
                        }
            rs.close();
            stmt.close();
            
		}
		catch (SQLException sqle){
			Log.error(this, "erreur dans loadVerst de ActionPiaDAO : "+sqle); 
            throw new DAOException(sqle.getMessage());
			
		}
		
		return a;
	}
	/**

	

	 */
	
	public void update(Connection conn, Object obj,String typact,String ancval,int oldreg) {
		ActionPia act=(ActionPia) obj;
		try 
		{
			PreparedStatement stmt = null;
			stmt = conn.prepareStatement(sqlUpAction);
				stmt.setString(1, act.getDomaine());
				stmt.setString(2, act.getLibAction());
				stmt.setString(3, act.getAcronyme());
				stmt.setString(4, act.getObs());
				stmt.setInt(5, act.getSit().getNumSite());
				stmt.setString(8, act.getOtp());
				stmt.setInt(6,act.getTpia().getNum());
				stmt.setString(7,act.getpCoord().getIdcoord());
				if (act.getDtfinconv().length()<10)
				{
					stmt.setString(8, null);
					System.out.println("Dtfinconv non renseign�e");
				}
				else
				stmt.setString(8, act.getDtfinconv());
				stmt.setString(9, act.getOtp());
				Log.info(this, "sql up - 2018 - +"+stmt);
				stmt.executeUpdate();
	        	stmt.close();
	        	upTypAct(conn,obj);
	        	gestCoord(conn,obj,typact,ancval);
	        	gestReg(conn,obj,oldreg);
	        	/*
	        	if ("R".equals(typact))
	        		return;
	        	if ("I".equals(typact))
	        	{
	        		PreparedStatement stmt2=null;
	        		stmt2=conn.prepareStatement(sqlInsCoord);
	        		stmt2.setString(1, act.getOtp());
	        		stmt2.setString(2, act.getpCoord().getIdcoord());
	        		stmt2.setString(3, act.getLibcoord());
	        		stmt2.execute();
	        		stmt2.close();
	        	}
	        	if ("U".equals(typact))
	        	{
	        		PreparedStatement stmt3=null;
	        		stmt3=conn.prepareStatement(sqlUpCoord);
	        		stmt3.setString(1, act.getpCoord().getIdcoord());
	        		stmt3.setString(2, act.getLibcoord());
	        		stmt3.setString(3, act.getOtp());
	        		stmt3.setString(4, ancval);
	        		stmt3.executeUpdate();
	        		stmt3.close();
	        	}
	        	if ("D".equals(typact))
	        	{
	        		PreparedStatement stmt4=null;
	        		stmt4=conn.prepareStatement(sqlDelCoord);
	        		stmt4.setString(1, act.getOtp());
	        		stmt4.setString(2, ancval);
	        		stmt4.execute();
	        		stmt4.close();
	        	}*/
	        	//conn.close();
		}
		catch (SQLException sqle) 
		{
			Log.error(this,"Erreur dans upd Act "+sqle);
		}
		
		
		
	}
	
	/**
	 *  
	 * 
	 */
	
	public void upTypAct(Connection conn, Object obj) {
		ActionPia act=(ActionPia) obj;
		try 
		{
			PreparedStatement stmt = null;
			stmt = conn.prepareStatement(sqlUpTypAct);
			stmt.setString(3, act.getOtp());
			stmt.setInt(1,act.getTpia().getNum());
			stmt.setInt(2,act.getTpia().getNum());
			Log.info(this,"sql up Typ Act +"+stmt);
			stmt.executeUpdate();
	       	stmt.close();
	       	//conn.close();
		}
		catch (SQLException sqle) 
		{
			Log.error(this,"Erreur dans up Typ Act "+sqle);
		}
		
		
		
	}
    
	/**
	 *  
	 * 
	 */
	
	public void gestReg(Connection conn, Object obj,int oldreg) {
		ActionPia act=(ActionPia) obj;
		try 
		{
			// 1. Suppression par pr�caution dans iaf1_reg
			int codreg=0;
			PreparedStatement stmt = null;
			stmt = conn.prepareStatement(sqlDelRegAct);
			stmt.setString(1, act.getOtp());
			stmt.setInt(2,oldreg);
			Log.info(this,"sql del iaf1_reg +"+stmt);
			stmt.executeUpdate();
			stmt.close();	
			
			// 2. Requ�te reg dans sitreg avec Cod_sit et comparaison de Cod_reg avec reg de act 
			PreparedStatement stmt2 = null;
			stmt2 = conn.prepareStatement(sqlSelSitReg);
			stmt2.setInt(1, act.getSit().getNumSite());
			Log.info(this,"Sel reg dans sitreg "+stmt2);
            ResultSet rs = stmt2.executeQuery();
            if (rs.next()){
                	codreg=rs.getInt("Cod_reg");
                        }
            rs.close();
            stmt2.close();
            
            if (codreg!=act.getReg().getCodReg())
            {
            	// insertion dans iaf1_reg 
            	
            	PreparedStatement stmt3 = null;
    			stmt3 = conn.prepareStatement(sqlInsActReg);
    			stmt3.setString(1, act.getOtp());
    			stmt3.setInt(2,act.getReg().getCodReg());
    			Log.info(this,"sql ins iaf1_reg +"+stmt3);
    			stmt3.executeUpdate();
    			stmt3.close();
            }
            //conn.close();
				
		}
		catch (SQLException sqle) 
		{
			Log.error(this,"Erreur dans gestReg "+sqle);
		}
		
		
		
	}
    
	
	public void gestCoord(Connection conn,Object obj,String typact, String ancval)
	{
		ActionPia act=(ActionPia) obj;
		try 
		{
				if ("R".equals(typact))
	        		return;
				if ("D".equals(typact)||"U".equals(typact))
	        	{
	        		PreparedStatement stmt4=null;
	        		stmt4=conn.prepareStatement(sqlDelCoord);
	        		stmt4.setString(1, act.getOtp());
	        		stmt4.setString(2, ancval);
	        		stmt4.execute();
	        		stmt4.close();
	        	}
	        	if ("I".equals(typact)||"U".equals(typact))
	        	{
	        		PreparedStatement stmt2=null;
	        		stmt2=conn.prepareStatement(sqlInsCoord);
	        		stmt2.setString(1, act.getOtp());
	        		stmt2.setString(2, act.getpCoord().getIdcoord());
	        		stmt2.setString(3, act.getLibcoord());
	        		stmt2.execute();
	        		stmt2.close();
	        		Log.info(this,"Maj Coord Ok");
	        	}
	        	/*
	        	if ("U".equals(typact))
	        	{
	        		PreparedStatement stmt3=null;
	        		stmt3=conn.prepareStatement(sqlUpCoord);
	        		stmt3.setString(1, act.getpCoord().getIdcoord());
	        		stmt3.setString(2, act.getLibcoord());
	        		stmt3.setString(3, act.getOtp());
	        		stmt3.setString(4, ancval);
	        		stmt3.executeUpdate();
	        		stmt3.close();
	        	}
	        	*/
	        	//conn.close();
	        	
		}
		catch (SQLException sqle) 
		{
			Log.error(this,"Erreur dans gest Coord "+sqle);
		}
		
	}
	
	/**
	 * 
	
	 * 
	 */
	
	/**
	
	  
	   Requ�te multi-crit�res active 
	   
	   - Programme de travail 2019-2020 => ajout du crit�re r�gion 
	     
	     (c[0]) et gr�ce � javascript, quand c[0] => !c[1] et inversement  
	     
	         
	         
	         --> Le Jeudi 30/01/2020 - Reprise apr�s un break.
	         
	         
	         
	          --> Le Mercredi 18/03/2020 
	          
	           -- Par rapport � la version environ - 7 jours, je n'ai que g�r� le quote
	           comme pour Site 
	           
	           ---> Il me semble que sur version Pc Mirabeau, il y avait outre le
	           fil d'Ariane, peut-�tre la partie inner v_act_reg 
	           
	           ... Pour pr�caution et meilleure gestion ult�rieure, je copie 
	               en findByCovid => Le voici 
	               
	               
	          --> Suite � P�ques 2020, le 14 Avril 2020, gestion de toute s�lection
	             => Coord + Part+ Sans doublon pour r�gion
	             
	          --> le Mercredi 6 Mai 2020 => g�rer c0 avec c3 c4 c5
	 */
	
	public Vector findByCovid(Connection conn,String[][] criteres,StringBuffer messsel)
	{
		Vector v=new Vector();
		int nb_c=6;
		try 
		{
			Boolean c[];
			c= new Boolean[nb_c];
			for (int i=0;i<nb_c;i++)
			{
				c[i]=false;
			}
			Boolean bj2=false;
			String req_final="";
			String join1="",join2="",join3="",join4="";
			String cond="",cond2="",cond3="",cond4="";
			String cond_bool="";
			String cond_iaf1="";
			String lib="",lib0="",lib1="",lib2="",lib3="",lib4="";
			String tri=" order by Otp";
			
			/*
			 * 
			 */
			
			for (int i=0;i<criteres.length;i++)
			{ 
				  if (!"".equals(criteres[i][1]) && criteres[i][1]!=null && 
						  !"RECHERCHE2".equals(criteres[i][0]) )
					  
			      // A revoir � l'occasion, je suis dubitatif sur RECHERCHE2 , il faut que le nom
				  // du crit�re, apparemment soit diff�rent de RECHERCHE2
				  {   
					  lib=criteres[i][1];
				   	  lib=lib.replace("'","''");
				   	  if (!"SITE".equals(criteres[i][0])&&!"REG".equals(criteres[i][0]))
				   		  lib=lib.replace(",","','");
				   	  
					  if ("REG".equals(criteres[i][0]))
					  {	  
						  c[0]=true;
						  lib0=lib;
						  String val0=RegDAO.findRegSel(conn, lib0);
						  messsel.append(" r�gion "+val0+"<BR>");
					  }
					  
					  if ("SITE".equals(criteres[i][0]))
					  {
						  c[1]=true;
						  lib1=lib;
						  String val=SiteDAO.findSiteSel(conn,lib1);
						  messsel.append(" site"+val+"<BR>");
						 // Le principe �tant de concat�ner les crit�res de s�lection en haut 
						 // de la page, qui renvoie les r�sultats dans missel, qui est un param�tre
						 // entrant vide et qui se concat�ne au fur et � mesure 
					  }
					  /* Reliquat d'un premier travail
					  if ("memb".equals(criteres[i][0]))
					  {
						  c[2]=true;
						  lib2=lib;
					  }
					  */					   
					  if ("COORD".equals(criteres[i][0]))
					  {
						  c[3]=true;
						  lib3=lib;
					  }
					  	  
					  if ("PART".equals(criteres[i][0]))
					  {	  
						  c[4]=true;
						  lib4=lib;
					  }
					  // Gestion du connecteur et ou sur coord et part
					  if ("PARTCOORD".equals(criteres[i][0])&&"1".equals(lib))
				   		  c[5]=true;
				   	  else if ("PARTCOORD".equals(criteres[i][0])&&"0".equals(lib))
				   		  c[5]=false;				  
				  }
					  
				
			}
			
			/*
			 * 
			 *  Partie B : g�n�ration de join1 � join4 et cond_bool 
			 * 
			 * 
			 */
			
			// Modification du 5/8/2016 
			
			// c03 rien � faire , aucun crit�re 
			
			// C13 => 3 cas REG seul, site seul, Part seul 
			
			// C23 =>3 cas  (reg,site), (reg,part), (site, Part) 
			
			// C33 reg, site et part 
			
			// Le 7/01/2015 - ajout des nouvelles r�gions
			
			/* -- Auteur : Andr� Guidi, Le 23/12/2019 , => c'est une partie ancestrale 
			
			if(c[0]&&!c[1]&&!c[2]&&!c[3]&&!c[4])
			{
				join1= "inner join Siret c on c.Siret=a.Siret_coord "+
					   "inner join bcn_commune d on c.com=d.Codcom5 " +
			           "inner join bcn_departement f on d.Dep=f.Dep3 " +
					   "inner join bcn_region e on f.Reg=e.Reg "+
			           "inner join bcn_region_nv g on e.Nv_reg=g.Reg";						
				cond=" where g.Reg="+lib0;
				Log.info(new Object(),"cas 1 - REG seul - ");
				
			}
			
			*/
			// C12 == e) PART seul c[4] � true tous les autres false, cas multiple in 
			if (!c[0]&&!c[1]&&!c[2]&&!c[3]&&c[4])
			{
				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				cond=" where b.Siret in ('"+lib4+"')";
				Log.info(new Object(),"cas 2 - PART seul - ");
				
			}
			// C22 
			//2.4 c0 et C4 REG et PART
			/* Partie obsol�te, qui avait �t� �crite dans un premier temps
			if(c[0]&&!c[1]&&!c[2]&&!c[3]&&c[4])
			{
				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp "+
			           "inner join Siret c on c.Siret=a.Siret_coord "+
					   "inner join bcn_commune d on c.com=d.Codcom5 " +
			           "inner join bcn_departement f on d.Dep=f.Dep3 " +
					   "inner join bcn_region e on f.Reg=e.Reg "+ 
			           "inner join bcn_region_nv g on g.Reg=e.Nv_reg ";
				
				cond=" where g.Reg="+lib0+" and b.SIRET in ('"+lib4+"')";
				Log.info(new Object(),"cas 3 - REG et PART - "); 
				
			}
			*/ 
			// Le 22/8/2016
			// On est parti sur un Cp3 (n=3 dans Cpn) 
			/*
			 * l� c'est c[1] � true et tt le reste � false, cas le plus basique 
			 */
			if (!c[0]&&c[1]&&!c[2]&&!c[3]&&!c[4])
			{
				join2="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				cond=" where a.C_site in ("+lib1+")";
				cond2=" where  b.Num_site in ("+lib1+") and ( a.C_site not in ("+lib1+") ) ";
				Log.info(new Object(), "Sel Site, c[1] ");

			}
			// ---> Ajout 2020, la r�gion sur le mod�le du site devenu groupement
			// partie li�e au confinement
			// Plusieurs cas 
			// c0 seul 
			if (c[0]&&!c[1]&&!c[2]&&!c[3]&&!c[4])
			{
     				join2="inner join `Siret-anr-part` b on a.Otp=b.Otp "
						+ "inner join `SitReg` rs on b.Num_site=rs.Cod_sit ";
					cond2=" where  rs.Cod_reg in ("+lib0+") and ( rs.Cod_reg <>ar.v_cod_reg ) ";
					join1= " ";
					cond=" where ar.v_cod_reg in ("+lib0+")";

				Log.info(new Object(), "Sel R�gion, c[0] ");

			}
			// c0 et c3 (coord) 
			if (c[0]&&!c[1]&&!c[2]&&c[3]&&!c[4])
			{
     				join2="inner join `Siret-anr-part` b on a.Otp=b.Otp "
						+ "inner join `SitReg` rs on b.Num_site=rs.Cod_sit ";
					cond2=" where  rs.Cod_reg in ("+lib0+") and ( rs.Cod_reg <>ar.v_cod_reg ) "
							+ "and a.Siret_coord in ('"+lib3+"') ";
					join1= " ";
					cond=" where ar.v_cod_reg in ("+lib0+") and a.Siret_coord in ('"+lib3+"') ";

				Log.info(new Object(), "Sel R�gion et coord , c[0] et c3");

			}
			// c0 et c4 (part)
			if (c[0]&&!c[1]&&!c[2]&&!c[3]&&c[4])
			{
     				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp " +
						 "inner join `SitReg` rs on b.Num_site=rs.Cod_sit ";
					cond=" where  rs.Cod_reg in ("+lib0+") "
							+ "and b.Siret in ('"+lib4+"') ";				
			
				Log.info(new Object(), "Sel R�gion et part , c[0] et c4");

			}
			// c0 c3 (coord) c4 (part) et !c5 (et)
			if (c[0]&&!c[1]&&!c[2]&&c[3]&&c[4]&&!c[5])
			{
     				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp " +
						 "inner join `SitReg` rs on b.Num_site=rs.Cod_sit ";
					cond=" where  ( rs.Cod_reg in ("+lib0+") or (ar.v_cod_reg in ("+lib0+") ) "
							+ "and b.Siret in ('"+lib4+"') and a.Siret_coord in ('"+lib3+"')";				
			
				Log.info(new Object(), "Sel R�gion coort et part , c[0] et c3,c4 et !c5");

			}
			// c0,c3,c4,c5 (r�gion, coord ou part, c0 c3 c4 c5)
			if (c[0]&&!c[1]&&!c[2]&&c[3]&&c[4]&&c[5])
			{
     				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp " +
						 "inner join `SitReg` rs on b.Num_site=rs.Cod_sit ";
					cond=" where  ( rs.Cod_reg in ("+lib0+") or (ar.v_cod_reg in ("+lib0+") ) "
							+ "and a.Siret_coord in ('"+lib3+"')";				
					join2="inner join `Siret-anr-part` b on a.Otp=b.Otp " +
							 "inner join `SitReg` rs on b.Num_site=rs.Cod_sit ";
						cond2=" where  ( rs.Cod_reg in ("+lib0+") or (ar.v_cod_reg in ("+lib0+") ) "
								+ "and b.Siret in ('"+lib4+"')";				
				
				Log.info(new Object(), "Sel R�gion coort et part , c[0] et c3,c4 et !c5");

			}



			/*
			 * C1 et c4 � true Site et part 
			 */
			if (!c[0]&&c[1]&&!c[2]&&!c[3]&&c[4])
			{
				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				cond=" where b.Siret in ('"+lib4+"') and ( a.C_site in ("+lib1+") or b.Num_site in ("+lib1+") ) ";
				//join2="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				//cond2=" where b.Num_site in ("+lib1+") and C_site not in ("+lib1+") and b.Siret in ('"+lib4+"')";
				Log.info(new Object(),"cas 2 - Site et PART - ");
				
			}
			//
			if(c[0]&&c[1]&&!c[2]&&!c[3]&&c[4])
			{
				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp "+
			           "inner join Siret c on c.Siret=a.Siret_coord "+
					   "inner join bcn_commune d on c.com=d.Codcom5 " +
			           "inner join bcn_departement f on d.Dep=f.Dep3 " +
					   "inner join bcn_region e on f.Reg=e.Reg "+ 
			           "inner join bcn_region_nv g on g.Reg=e.Nv_reg " +
			           "left join `Siret-anr-part` h on a.Otp=h.Otp ";
				
				cond=" where g.Reg="+lib0+" and b.SIRET in ('"+lib4+"') and "+
				"( h.Num_site in ("+lib1+") or a.C_site in ("+lib1+"))";
				Log.info(new Object(),"cas 5 - REG, PART, Site - "); 
				
			}
			//

			if(c[0]&&c[1]&&!c[2]&&!c[3]&&!c[4])
			{
				join1= "inner join Siret c on c.Siret=a.Siret_coord "+
					   "inner join bcn_commune d on c.com=d.Codcom5 " +
			           "inner join bcn_departement f on d.Dep=f.Dep3 " +
					   "inner join bcn_region e on f.Reg=e.Reg "+
			           "inner join bcn_region_nv g on e.Nv_reg=g.Reg "+
			           "left join `Siret-anr-part` h on a.Otp=h.Otp ";						
				cond=" where g.Reg="+lib0+" and "+
						"( h.Num_site in ("+lib1+") or a.C_site in ("+lib1+"))";
				Log.info(new Object(),"cas 6 - REG seul & Site - ");
				
			}
			
			/**
			 * Modification du 17/11/2016. Je g�re le cas o� c[3] est � true et tous les cas
			 * de figure avec en oubliant peut-�tre c[0] et c[2] qui ne sont plus actifs mais en
			 * int�grant c[5] et notamment les deux cas c3,c4 et c5 (avec union) 
			 * puis c3,c4 et non c5 (sans union) 
			 * 
			 * Jusqu'alors c3 n'�tait pas g�r�, il �tait repouss� plus loin puisqu'il n'impliquait
			 * pas de jointure particuli�re
			 */
			// ici pas besoin de tester c[5] puisque c'est !c[4]
			if(!c[0]&&!c[1]&&!c[2]&&c[3]&&!c[4])
			{
				cond=" where a.Siret_coord in ('"+lib3+"') ";
			}
			if(!c[0]&&!c[1]&&!c[2]&&c[3]&&c[4]&&!c[5])
			{
				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				cond=" where b.Siret in ('"+lib4+"') and a.Siret_coord in ('"+lib3+"') ";
			}
			if(!c[0]&&!c[1]&&!c[2]&&c[3]&&c[4]&&c[5])
			{
				join2="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				cond=" where a.Siret_coord in ('"+lib3+"') ";
				cond2=" where b.Siret in ('"+lib4+"') ";
			}
			/*
			 * on rajoute c1 dans le test 
			 */
			if(!c[0]&&c[1]&&!c[2]&&c[3]&&!c[4])
			{
			join2="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
			cond=" where a.C_site in ("+lib1+") and a.Siret_coord in ('"+lib3+"') ";
			cond2=" where  b.Num_site in ("+lib1+") and ( a.C_site not in ("+lib1+") ) and a." +
					"Siret_coord in ('"+lib3+"') ";
			}
			if(!c[0]&&c[1]&&!c[2]&&c[3]&&c[4]&&!c[5])
			{
				join1="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				cond=" where b.Siret in ('"+lib4+"') and a." +
						"Siret_coord in ('"+lib3+"') and (a.C_site in ("+lib1+") or b.Num_site in ("+lib1+") ) ";
			}
			if(!c[0]&&c[1]&&!c[2]&&c[3]&&c[4]&&c[5])
			{   join1="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				join2="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
				cond=" where a.Siret_coord in ('"+lib3+"') and (a.C_site in ("+lib1+") " +
						"or b.Num_site in ("+lib1+") ) ";
				cond2=" where b.Siret in ('"+lib4+"') and (a.C_site in ("+lib1+") or b.Num_site in ("+lib1+") ) ";
			}
			/**
			 * 
			 * Partie C 
			 * 
			 * 
			 * - gestion diff�rentielle avec les conditions portant sur des colonnes de la table
			 *   des actions iaf1 et celles associ�es aux colonnes des tables jointes qui valorisent
			 *   lib0 � lib4 reprises dans la partie B
			 * 
			 *   If majeur (� reprendre apr�s adaptation du findByCriteres )  
			 *   
			 *     g�n�ration �ventuelle du where puis g�n�ration du and sous condition des colonnes 
			 *     d'iaf1 
			 *   
			 *   puis s�rie de if sur chaque critere de la jsp 
			 *   
			 *    C.1 Colonnes iaf1 => cond_iaf1 
			 *    C.2 Colonnes autres tables => lib0 � lib4 et cond_bool  
			 *   
			 *  
			 * 
			 */
			//String req = "select distinct PIA1,Vagues,Type,Idex,IdIa,LibLongProj,Date1,a.Otp,Domaine,a.Acronyme,DC,IDNC,DNC"; 
			//String req = "select distinct a.Cle_act,a.Otp,Val_pia,Vague,Type_act,Sigle_type_act,a.Acronyme,a.Lib,Date_decision,Domaine," +
			//					"C_site,Obs,Otp_ratt,Siret_coord,Dnc,Dc,Idnc,Obs,C_site,C_tpia,EtablissementCoordinateur,y.Lib ";
			String req = "select distinct a.Cle_act,a.Otp,a.Otp_anr,a.Val_pia,a.Vague,a.Type_act,a.Sigle_type_act," +
					"a.Acronyme,a.Lib,a.Date_decision,a.Domaine," +
					"a.C_site,a.Obs,ab.Sigle_tpia,a.Siret_coord,a.Dnc,a.Dc,a.Idnc,"
					+ "a.Ction,a.Verst,a.Dtfinconv," +
					"a.C_site,a.C_tpia,y.Lib Libsit,z.EtablissementCoordinateur Libcoord,Lib_tetab,a.Otp_ratt,ar.v_cod_reg,"
					+ "ar.v_lib_reg,ar.v_cod_reg ";
		
			//String req = "select distinct a.Cle_act,a.Otp,Val_pia,Vague,Type_act,Sigle_type_act,a.Acronyme,a.Lib,Date_decision,Domaine," +
			//        	"C_site,Obs,Otp_ratt,Siret_coord,Dnc,Dc,Idnc,Obs,C_site,C_tpia "; 
	
  	String reqf=" from iaf1 a left join iaf1 aa on a.Otp_ratt=aa.Otp left join Type_pia ab on" +
  			" aa.C_tpia=ab.Num_tpia left join v_act_reg ar on a.Otp=ar.Otp ";
			
			 for(int i=0; i<criteres.length; i++)
			   { 
				   if (!"".equals(criteres[i][1]) && criteres[i][1]!=null && !"RECHERCHE2".equals(criteres[i][0]) )
				   {					   
					   Log.info(new Object(),"Crit" + criteres[i][0]);
	            	   Log.info(new Object(),"val Crit" + criteres[i][1]);
					   //if ("".equals(cond))
					   //   reqf+=" where ";
					   lib=criteres[i][1];
					   if (!"SITE".equals(criteres[i][0]))
					   {	   
						   lib=lib.replace("'","''");
						   lib=lib.replace(",","','");
					   }
					   // A.1 
					   if ("ANNEE".equals(criteres[i][0]))
					   {  
						   if (!"".equals(cond))
						   {				   
						   	   cond+=" and ";
							   cond+=" year(a.Date1)="+lib;
						   }
						   else 
						   cond+=" where year(a.Date1)="+lib;
					   }
					   if("TYP_PIA".equals(criteres[i][0]))
					   {
						   if (!"".equals(cond))
						   {	   
							   cond+=" and ";
						   cond+="a.PIA1='"+lib+"'";
						   }
						   else 
						   cond+=" where a.PIA1='"+lib+"'";
					   }
					   if("VAGUE_PIA".equals(criteres[i][0]))
					   {
						   if (!"".equals(cond))
							   cond+=" and ";
						   cond+="a.Vagues='"+lib+"'";
					   }
					   if("TYPE_ACTION".equals(criteres[i][0]))
					   {   
						  // bj2=true;
						   if ("".equals(cond2))
						   {
						     // join2="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
						     // cond2=" where   a.C_tpia = '"+lib+"'";
						   }
						   else 
							   cond2+= " and  a.C_tpia in ('"+lib+"')";
						   if (!"".equals(cond))
						   {	   
							   cond+=" and ";
							   cond+="a.C_tpia in ('"+lib+"')";

						   }
						   else 
							   cond+="where a.C_tpia in ('"+lib+"')";

						   
						   String val=TypePiaDAO.findTpiaSel(conn,lib);
					       messsel.append(" type action "+val+"<BR>");
					   }
					   /*
					   if("COORD".equals(criteres[i][0]))
					   {
						   if (!"".equals(cond))
						   {	   
							   cond+=" and ";
							   cond+="Siret_coord in ('"+lib+"')";
						   }
						   else 
							   cond+=" where Siret_coord in ('"+lib+"')";
						   if (!"".equals(cond2))
						   {   
							   cond2+=" and ";
							   cond2+="Siret_coord in ('"+lib+"')";
						   }
						   else 
						   cond2+=" where Siret_coord in ('"+lib+"')";
					   }
					   */
					   if("DOMAINE".equals(criteres[i][0]))
					   {   
						   // bj2=true;
						   if ("".equals(cond2))
						   {
						   //  join2="inner join `Siret-anr-part` b on a.Otp=b.Otp ";
						   //	 cond2=" where   a.Domaine in ('"+lib+"')";
						   }
						   else 
							 cond2+=" and a.Domaine in ('"+lib+"')";
						   if (!"".equals(cond))
						   {	   
							   cond+=" and ";
						   cond+="a.Domaine in ('"+lib+"')";
						   }
						   else 
							   cond+=" where a.Domaine in ('"+lib+"')";
						   
						   messsel.append(" domaine "+lib.replace("','"," ")+"<BR>");
					   }
					   //
					   if("OTP".equals(criteres[i][0]))
					   {
						   if (!"".equals(cond))
						   {	   
							   cond+=" and ";
						   lib=lib.toUpperCase();
						   cond+="a.Otp like '%"+lib+"%'";
						   }
						   else
						   {
							   lib=lib.toUpperCase();
							   cond+=" where a.Otp like '%"+lib+"%'";
						   }
					   }
					   if("PIA.LIBELLE".equals(criteres[i][0])){
					    	if (!"".equals(cond))
					    	{		
								   cond+=" and ";
    	        	lib = lib.toLowerCase();
    	        	cond += " ( lower(a.Acronyme) like '%"+lib+"%' or " +
    	           			"lower(a.Lib) like'%"+lib+"%' )";
					    	}
					    	else
					    	{
					    		lib = lib.toLowerCase();
		          	        	cond += " where ( lower(a.Acronyme) like '%"+lib+"%' or " +
		          	           			"lower(a.Lib) like'%"+lib+"%' )";
					    	}
					    	if (!"".equals(cond2))
					    	{		
								   cond2+=" and ";
    	        	lib = lib.toLowerCase();
    	        	cond2 += " ( lower(a.Acronyme) like '%"+lib+"%' or " +
    	           			"lower(a.Lib) like'%"+lib+"%' )";
					    	}
					    	else
					    	{
					    		lib = lib.toLowerCase();
		          	        	cond2 += " where ( lower(a.Acronyme) like '%"+lib+"%' or " +
		          	           			"lower(a.Lib) like'%"+lib+"%' )";
					    	}
					    
					    	 messsel.append(" libell� "+lib+"<BR>");
    	           	}
					   /*
					   if ("SITE".equals(criteres[i][0]))
					   {
						   if (!"".equals(cond))
							   cond+=" and ";
						   cond+="C_site in ("+lib+")";
					   }
					   */
					   // C.2
					   
					   /*if("REG".equals(criteres[i][0]))
					   {
						 //  lib0=lib;
						 // Mis en commentaire, suite � remarque de Balarin 
						  req+=",g.Libmin,d.Lib70,Libet,Codcom5 ";
					   }
					   */
					   if ("COMUE".equals(criteres[i][0]))
					   {
							// lib1=lib;
							// req+=",Comue.Libcourtparent ";
					   }
					   /*
					   if ("memb".equals(criteres[i][0]))
							 lib2=lib;
					   if ("COORD".equals(criteres[i][0]))
							 lib3=lib;
					   if ("PART".equals(criteres[i][0]))
							 lib4=lib;
					   */
					   
					   
					   
				   }
				   
			   }
				
			
			/*
			 * 
			 *  Partie D : G�n�ration de la requ�te avec les briques �l�mentaires construites
			 *  pr�c�demment 
			 * 
			
			 * 
			 *  Ajout dans le select de typetab � 1 (Coord) et � 2 (Part) pour le crit�re r�gion 
			 *  ainsi que dans le tri 
			 * 
			 */
			String req1="",req2="",req3="",req4="";
			
			req1=req+reqf;
			
			if (c[1]||c[0]||bj2)
			{
				req1=req+",'1' typetab "+reqf;
				tri=" order by typetab,Acronyme ";
			}
			if ("".equals(join1)&&"".equals(join2)&&"".equals(join3)&&"".equals(join4))
				req_final=req1+cond;
			//if (!"".equals(join1))
			//{ 
			    join1+=" left join `Siret-anr-coord` z on a.Siret_coord=z.SIRET  and a.Otp=z.Otp left join Site y " +
					" on a.C_site=y.Num_site left join `v_Siret` x on a.Siret_coord=x.Siret ";
				req1+=join1+cond;
          req_final=req1;				
			
			//}
			if (!"".equals(join2))
			{
				join2+=" left join `Siret-anr-coord` z on a.Siret_coord=z.SIRET and a.Otp=z.Otp left join Site y " +
						" on a.C_site=y.Num_site left join `v_Siret` x on a.Siret_coord=x.Siret ";
				req2=req+reqf+join2+cond2;
				if (c[1]||c[0]||bj2)
					req2=req+",'2' typetab "+reqf+join2+cond2;				
				req_final+=" union "+req2;
			}
			if (!"".equals(join3))
			{
				req3=req+reqf+join3+cond;
				if (c[0])
					req3=req+",'1' typetab "+reqf+join3+cond;
				req_final+=" union "+req3;
			}
			if (!"".equals(join4))
			{
				req4=req+reqf+join4+cond;
				if (c[0])
					req4=req+",'2' typetab "+reqf+join4+cond;
				req_final+=" union "+req4;
			}
			
			req_final+=tri;
			
			Log.info(new Object(),"req : "+req_final);
			
			PreparedStatement stmt = conn.prepareStatement(req_final);

			reqSqlCoord=req1;
      reqSqlPart=req2;
      reqSqlCoordMemb=req3;
      reqSqlPartMemb=req4;
      
      if (c[2])
      	memb=true;
      else
      	memb=false; 
      
      ResultSet rs = stmt.executeQuery();
      
      
     
      int compteur=0;
      while(rs.next()){
      	compteur++;   
      	ActionPia act=new ActionPia();
      	act.setCleAct(rs.getInt("Cle_act"));
      	act.setTypePia(rs.getString("Val_pia"));
      	act.setDatePM(rs.getString("Date_decision"));
      	act.setTypeAction(rs.getString("Sigle_type_act"));
      	act.setDc(rs.getDouble("Dc"));
      	act.setIdnc(rs.getDouble("Idnc"));
      	act.setDnc(rs.getDouble("Dnc"));
      	act.setDtfinconv(rs.getString("Dtfinconv"));
      	act.setOtp(rs.getString("Otp"));
      	act.setOtp_anr(rs.getString("Otp_anr"));
      	act.setIdex(rs.getString("Otp_ratt"));
      	act.setTypRatt(rs.getString("Sigle_tpia"));
      	act.setLibAction(rs.getString("Lib"));
      	act.setDomaine(rs.getString("Domaine"));
//      	act.setIdIa(rs.getString("IdIa"));
      	act.setAcronyme(rs.getString("Acronyme"));
      	act.setObs(rs.getString("Obs"));
      	act.setLibcoord(rs.getString("Libcoord"));
      	act.setLibtetab(rs.getString("Lib_tetab"));
      	act.setVt(rs.getDouble("Verst"));
      	act.setCtion(rs.getDouble("Ction"));
      	Reg reg=new Reg();
      	Commune com=new Commune();
      	Etab et=new Etab();
      	/*if (c[0])
      	{
      		reg.setLibReg(rs.getString("Libmin"));
      		com.setLibcom(rs.getString("Lib70"));
      		com.setCodcom(rs.getString("Codcom5"));
      	//	et.setTypEtab(rs.getString("typetab"));
          //  et.setLibelle(rs.getString("Libet"));
      		et.setTypEtab("");
      		et.setLibelle("");
      	}
      	else 
      	{*/	
      	// Partie sur r�gion - ajout�e le 19/03/2020
      		reg.setLibReg(rs.getString("v_lib_reg"));
      		reg.setCodReg(rs.getInt("v_cod_reg"));
      		act.setReg(reg);
      		com.setLibcom("");
      		com.setCodcom("");
      		et.setTypEtab("");
      		et.setLibelle("");
  //    	}
      	if(c[1]||c[0]||bj2) {et.setTypEtab(rs.getString("typetab"));}
      	/*
      	reg.setLibReg("");
  		com.setLibcom("");
  		*/        	
      	Comue comue=new Comue();
      	/*
      	if (c[1])
      	   comue.setLib(rs.getString("Libcourtparent"));
      	else
      	*/
      	   comue.setLib("");
      	 //  comue.setSiret(rs.getString("SiretComue"));
      	//act.setReg(reg);
          act.setCom(com);
          act.setComue(comue);
          /*
           * Gestion du site - version 2016 - 
           */
          Site s=new Site();
          s.setNumSite(rs.getInt("C_site"));
          s.setLib(rs.getString("Libsit"));
          act.setSit(s);
          /*
           * Gestion du type d'action - 
           */
          TypePia ta=new TypePia();
          ta.setNum(rs.getInt("C_tpia"));
          act.setTpia(ta);
          /*
           * Gestion de la classe Etab encapsul�e dans la classe ActionPia   
           */
          
          
          act.setEtab(et);
      	v.addElement(act);
      }
      
      rs.close();
      stmt.close();
      
      /**
       * Fin de m�thode , gestion de la s�lection des Coord et Part 
       * 
       */
      if (c[3]&!c[4])
      {
      	  String val=EtabDAO.findCoordSel(conn, lib3);
		       messsel.append(" Coord "+val+"<BR>");		       
      }
      if (!c[3]&c[4])
      {
      	  String val=EtabDAO.findPartSel(conn, lib4);
		       messsel.append(" Part "+val+"<BR>");		       
      }
      if (c[3]&c[4]&c[5])
      {
      	  String val=" Coord "+EtabDAO.findCoordSel(conn, lib3)+ " Ou Part "+EtabDAO.findPartSel(conn, lib4);
		       messsel.append(val+"<BR>");		       
      }
      if (c[3]&c[4]&!c[5])
      {
      	  String val=" Coord "+EtabDAO.findCoordSel(conn, lib3)+ " Et Part "+EtabDAO.findPartSel(conn, lib4);
		       messsel.append(val+"<BR>");		       
      }
      
     // conn.close();
			
		}
		catch (SQLException sqle)
		{
			commun.Log.error("Erreur sql findByCombi2020 "+sqle);
		}
		catch(Exception e)
		{
			commun.Log.error("Exception findByCombi2020 "+e);
		}
		return v;
	}    
	

/**	
	requ�tes sql
	
**/

	private static final String sqlUpAction=CodeSQL.getString("ActionDAO.update");
	private static final String sqlInsAction=CodeSQL.getString("ActionDAO.insert");
	private static final String sqlUpTypAct=CodeSQL.getString("ActionDAO.upTypAct");
	private static final String sqlLitVerst=CodeSQL.getString("ActionDAO.litVerst");
	private static final String sqlInsCoord=CodeSQL.getString("ProjPartDAO.inscoord");
	private static final String sqlUpCoord=CodeSQL.getString("ProjPartDAO.upcoord");
	private static final String sqlDelCoord=CodeSQL.getString("ProjPartDAO.delcoord");
	private static final String sqlDelRegAct=CodeSQL.getString("RegActDAO.del");
	private static final String sqlSelSitReg=CodeSQL.getString("SitRegDAO.sel");
	private static final String sqlInsActReg=CodeSQL.getString("ActRegDAO.ins");

	@Override
	public void update(Connection arg0, Object arg1) throws DAOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(Connection arg0, Object arg1) throws DAOException {
		// TODO Auto-generated method stub
		
	}

}

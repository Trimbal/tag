/* variable otp - CopyRight MT-TAG  - */ private Sring otp; // Getter Setter de otp - CopyRight MT-TAG - public Sring getOtp   { return otp; }   public void setOtp (Sring otp){ this.otp =  otp; } 
 
/* variable acr_act - CopyRight MT-TAG  - */ private Sring acr_act; // Getter Setter de acr_act - CopyRight MT-TAG - public Sring getAcr_act   { return acr_act; }   public void setAcr_act (Sring acr_act){ this.acr_act =  acr_act; } 
 
/* variable lib_act - CopyRight MT-TAG  - */ private Sring lib_act; // Getter Setter de lib_act - CopyRight MT-TAG - public Sring getLib_act   { return lib_act; }   public void setLib_act (Sring lib_act){ this.lib_act =  lib_act; } 
 
/* variable datdeb_act - CopyRight MT-TAG  - */ private Sring datdeb_act; // Getter Setter de datdeb_act - CopyRight MT-TAG - public Sring getDatDeb_act   { return datdeb_act; }   public void setDatDeb_act (Sring datdeb_act){ this.datdeb_act =  datdeb_act; } 
 
/* variable datfin_act - CopyRight MT-TAG  - */ private Sring datfin_act; // Getter Setter de datfin_act - CopyRight MT-TAG - public Sring getDatFin_act   { return datfin_act; }   public void setDatFin_act (Sring datfin_act){ this.datfin_act =  datfin_act; } 
 
/* variable dc - CopyRight MT-TAG  - */ private int dc; // Getter Setter de dc - CopyRight MT-TAG - public int getDc   { return dc; }   public void setDc (int dc){ this.dc =  dc; } 
 
/* variable dnc - CopyRight MT-TAG  - */ private int dnc; // Getter Setter de dnc - CopyRight MT-TAG - public int getDnc   { return dnc; }   public void setDnc (int dnc){ this.dnc =  dnc; } 
 
/* variable idnc - CopyRight MT-TAG  - */ private int idnc; // Getter Setter de idnc - CopyRight MT-TAG - public int getIdnc   { return idnc; }   public void setIdnc (int idnc){ this.idnc =  idnc; } 
 
/* variable ction - CopyRight MT-TAG  - */ private int ction; // Getter Setter de ction - CopyRight MT-TAG - public int getCtion   { return ction; }   public void setCtion (int ction){ this.ction =  ction; } 
 
/* variable otp_ori - CopyRight MT-TAG  - */ private Sring otp_ori; // Getter Setter de otp_ori - CopyRight MT-TAG - public Sring getOtp_ori   { return otp_ori; }   public void setOtp_ori (Sring otp_ori){ this.otp_ori =  otp_ori; } 
 
/* variable typ_act - CopyRight MT-TAG  - */ private Typ_act typ_act; // Getter Setter de typ_act - CopyRight MT-TAG - public Typ_act getTyp_act   { return typ_act; }   public void setTyp_act (Typ_act typ_act){ this.typ_act =  typ_act; } 
 
/* variable domaine - CopyRight MT-TAG  - */ private Domaine domaine; // Getter Setter de domaine - CopyRight MT-TAG - public Domaine getDomaine   { return domaine; }   public void setDomaine (Domaine domaine){ this.domaine =  domaine; } 
 
/* variable porteur - CopyRight MT-TAG  - */ private Porteur porteur; // Getter Setter de porteur - CopyRight MT-TAG - public Porteur getPorteur   { return porteur; }   public void setPorteur (Porteur porteur){ this.porteur =  porteur; } 
 
/* variable partenaire - CopyRight MT-TAG  - */ private Vector <Partenaire> partenaire; // Getter Setter de partenaire - CopyRight MT-TAG - public Vector <Partenaire> getPartenaire   { return partenaire; }   public void setPartenaire (Vector <Partenaire> partenaire){ this.partenaire =  partenaire; } 
 
/* variable objectif - CopyRight MT-TAG  - */ private Vector <Objectif> objectif; // Getter Setter de objectif - CopyRight MT-TAG - public Vector <Objectif> getObjectif   { return objectif; }   public void setObjectif (Vector <Objectif> objectif){ this.objectif =  objectif; } 
 
/* variable pt-vigil - CopyRight MT-TAG  - */ private Vector <Pt-vigil> pt-vigil; // Getter Setter de pt-vigil - CopyRight MT-TAG - public Vector <Pt-vigil> getPt-vigil   { return pt-vigil; }   public void setPt-vigil (Vector <Pt-vigil> pt-vigil){ this.pt-vigil =  pt-vigil; } 
 
/* variable indic - CopyRight MT-TAG  - */ private Vector <Indic> indic; // Getter Setter de indic - CopyRight MT-TAG - public Vector <Indic> getIndic   { return indic; }   public void setIndic (Vector <Indic> indic){ this.indic =  indic; } 
 

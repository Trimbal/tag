/* variable cod_partenaire - CopyRight MT-TAG  - */ private Sring cod_partenaire; // Getter Setter de cod_partenaire - CopyRight MT-TAG - public Sring getCod_Partenaire   { return cod_partenaire; }   public void setCod_Partenaire (Sring cod_partenaire){ this.cod_partenaire =  cod_partenaire; } 
 
/* variable lib_part - CopyRight MT-TAG  - */ private Sring lib_part; // Getter Setter de lib_part - CopyRight MT-TAG - public Sring getLib_part   { return lib_part; }   public void setLib_part (Sring lib_part){ this.lib_part =  lib_part; } 
 
/* variable datdeb - CopyRight MT-TAG  - */ private Sring datdeb; // Getter Setter de datdeb - CopyRight MT-TAG - public Sring getDatDeb   { return datdeb; }   public void setDatDeb (Sring datdeb){ this.datdeb =  datdeb; } 
 
/* variable datfin - CopyRight MT-TAG  - */ private Sring datfin; // Getter Setter de datfin - CopyRight MT-TAG - public Sring getDatFin   { return datfin; }   public void setDatFin (Sring datfin){ this.datfin =  datfin; } 
 
/* variable dc - CopyRight MT-TAG  - */ private int dc; // Getter Setter de dc - CopyRight MT-TAG - public int getDc   { return dc; }   public void setDc (int dc){ this.dc =  dc; } 
 
/* variable dnc - CopyRight MT-TAG  - */ private int dnc; // Getter Setter de dnc - CopyRight MT-TAG - public int getDnc   { return dnc; }   public void setDnc (int dnc){ this.dnc =  dnc; } 
 
/* variable idnc - CopyRight MT-TAG  - */ private int idnc; // Getter Setter de idnc - CopyRight MT-TAG - public int getIdnc   { return idnc; }   public void setIdnc (int idnc){ this.idnc =  idnc; } 
 
/* variable ction - CopyRight MT-TAG  - */ private int ction; // Getter Setter de ction - CopyRight MT-TAG - public int getCtion   { return ction; }   public void setCtion (int ction){ this.ction =  ction; } 
 
/* variable verst - CopyRight MT-TAG  - */ private int verst; // Getter Setter de verst - CopyRight MT-TAG - public int getVerst   { return verst; }   public void setVerst (int verst){ this.verst =  verst; } 
 

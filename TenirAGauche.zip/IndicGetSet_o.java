/* variable c_ind - CopyRight MT-TAG  - */ private int c_ind; // Getter Setter de c_ind - CopyRight MT-TAG - public int getC_ind   { return c_ind; }   public void setC_ind (int c_ind){ this.c_ind =  c_ind; } 
 
/* variable lib_ind - CopyRight MT-TAG  - */ private Sring lib_ind; // Getter Setter de lib_ind - CopyRight MT-TAG - public Sring getLib_ind   { return lib_ind; }   public void setLib_ind (Sring lib_ind){ this.lib_ind =  lib_ind; } 
 
/* variable c_tri_ind - CopyRight MT-TAG  - */ private int c_tri_ind; // Getter Setter de c_tri_ind - CopyRight MT-TAG - public int getC_tri_ind   { return c_tri_ind; }   public void setC_tri_ind (int c_tri_ind){ this.c_tri_ind =  c_tri_ind; } 
 
